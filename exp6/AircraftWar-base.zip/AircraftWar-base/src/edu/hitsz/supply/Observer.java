package edu.hitsz.supply;

public interface Observer {
void update(boolean flag);
}
