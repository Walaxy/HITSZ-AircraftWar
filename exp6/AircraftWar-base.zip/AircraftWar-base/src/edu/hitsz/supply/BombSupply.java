package edu.hitsz.supply;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.AbstractEnemyAircraft;
import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.application.Main;
import edu.hitsz.basic.AbstractFlyingObject;
import edu.hitsz.bullet.BaseBullet;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wlx04
 */
public class BombSupply extends AbstractSupply {
    private final List<Observer> subscribers = new ArrayList<>();

    private int scoreAward;

    public BombSupply(int locationX, int locationY, int speedX, int speedY) {
        super(locationX, locationY, speedX, speedY);
    }


    @Override
    public void activate(HeroAircraft heroAircraft, List<BaseBullet> enemyBullets, List<AbstractAircraft> enemyAircrafts) {
        System.out.println("BombSupply active!");

        this.scoreAward = 0;

        for (AbstractFlyingObject enemyAircraft : enemyAircrafts) {
            if (enemyAircraft.notValid()) {
                continue;
            }
            addSubscriber((Observer) enemyAircraft);
        }

        for (AbstractFlyingObject enemyBullet : enemyBullets) {
            if (enemyBullet.notValid()) {
                continue;
            }
            addSubscriber((Observer) enemyBullet);
        }

        notifyAllSubscribers();
        removeAllSubscriber();
    }

    @Override
    public void forward() {
        super.forward();
        // 判定 y 轴向下飞行出界
        if (locationY >= Main.WINDOW_HEIGHT) {
            vanish();
        }
    }


    public void notifyAllSubscribers() {
        for (Observer subscriber : subscribers) {
            subscriber.update(true);
            if(subscriber instanceof AbstractEnemyAircraft){
                scoreAward += ((AbstractEnemyAircraft) subscriber).getScoreAward();
            }
        }
    }


    public void addSubscriber(Observer observer) {
        subscribers.add(observer);
    }

    public void removeAllSubscriber() {
        subscribers.clear();
    }
    public int getScoreAward() {
        return scoreAward;
    }

}
