package edu.hitsz.record;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static edu.hitsz.application.Main.game;

public class recordDaoImpl implements recordDao {
    private final List<record> records;
    public recordDaoImpl() {
        records = new ArrayList<record>();
    }
    @Override
    public List<record> getAllRecords() {
        return records;
    }


    @Override
    public void findById(int recordId){
        for (record item:records){
            if(item.getRecordId()==recordId){
                System.out.println("ID:"+(item.getRecordId()));
                System.out.println("Username:"+item.getUserName());
                System.out.println("Time:"+item.getTime());
                System.out.println("Score"+item.getScore());
                return;
            }
        }
        System.out.println("No such record!");
    }
    @Override
    public void doDelete(int recordId){
        for (record item:records){
            if(item.getRecordId()==recordId){
                records.remove(item);
                return;
            }
        }
        System.out.println("No such record!");
    }
    @Override
    public void doAdd(record record){
        records.add(record);

    }
    public void fileWriter(){
        String fileName = null;
        if(Objects.equals(game.difficulty, "Easy")) {
            fileName = "src/edu/hitsz/record/easy-record.txt";
        }
        else if(Objects.equals(game.difficulty, "Common")){
            fileName = "src/edu/hitsz/record/common-record.txt";
        }
        else if(Objects.equals(game.difficulty, "Hard")){
            fileName = "src/edu/hitsz/record/Hard-record.txt";
        }


        try{
            FileWriter writer = new FileWriter(fileName, true);
            for (record item:records){
                writer.write("Username:"+item.getUserName()+",Time:"+item.getTime()+",Score:"+item.getScore()+"\n");

            }
            writer.close();
        } catch (IOException e) {
            System.out.println("写入文件错误"+e.getMessage());
        }
    }
    @Override
    public int getRecordNum(){
        return records.size();
    }
}