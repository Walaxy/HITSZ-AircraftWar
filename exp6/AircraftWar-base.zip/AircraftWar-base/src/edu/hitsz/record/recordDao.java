package edu.hitsz.record;

import java.util.List;

public interface recordDao {


    List<record> getAllRecords();

    void findById(int recordId);
    void doAdd(record record);
    void doDelete(int recordId);




    void fileWriter();

    int getRecordNum();
}
