package edu.hitsz.aircraft;

import edu.hitsz.factory.BombSupplyFactory;
import edu.hitsz.factory.FireSupplyFactory;
import edu.hitsz.factory.HealingSupplyFactory;
import edu.hitsz.factory.SupplyFactory;
import edu.hitsz.supply.AbstractSupply;

import java.util.List;

public abstract class AbstractEnemyAircraft extends AbstractAircraft {

    protected int scoreAward;
    public AbstractEnemyAircraft(int locationX, int locationY, int speedX, int speedY, int hp, int shootNum, int power, int direction, boolean isHero) {
        super(locationX, locationY, speedX, speedY, hp, shootNum, power, direction, false);
    }

    public void forward() {
        super.forward();
        // 判定 y 轴向下飞行出界
        if (locationY >= edu.hitsz.application.Main.WINDOW_HEIGHT) {
            vanish();
        }
    }



    public void generateSupply(List<AbstractSupply> supplys) {
        SupplyFactory supplyfactory;
        double rate = Math.random();
        if (rate > 0.9) {
            // 不产生随机道具
            return;
        } else if (rate > 0.6) {
            supplyfactory = new BombSupplyFactory();
            //System.out.println("产生bomb");

        } else if (rate > 0.3) {
            supplyfactory = new HealingSupplyFactory();
            //System.out.println("产生healing");
        } else {
            supplyfactory = new FireSupplyFactory();
            //System.out.println("产生fire");
        }
        supplys.add(supplyfactory.createSupply(locationX, locationY, 0, 5));
    }
    public int getScoreAward() {
        return this.scoreAward;
    }


}
