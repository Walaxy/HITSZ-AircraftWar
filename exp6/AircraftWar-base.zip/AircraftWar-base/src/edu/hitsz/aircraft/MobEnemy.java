package edu.hitsz.aircraft;

import edu.hitsz.application.Main;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.supply.AbstractSupply;
import edu.hitsz.supply.Observer;

import java.util.LinkedList;
import java.util.List;

/**
 * 普通敌机
 * 不可射击
 *
 * @author hitsz
 */
public class MobEnemy extends AbstractEnemyAircraft implements Observer {

    public int getScoreAward() {
        return 30;
    }

    public MobEnemy(int locationX, int locationY, int speedX, int speedY, int hp, int shootNum, int power, int direction, boolean isHero) {
        super(locationX, locationY, speedX, speedY, hp, shootNum, power, direction, false);
    }

    @Override
    public void forward() {
        super.forward();
        // 判定 y 轴向下飞行出界
        if (locationY >= Main.WINDOW_HEIGHT) {
            vanish();
        }
    }

    @Override
    public List<BaseBullet> shoot() {
        return new LinkedList<>();
    }

    @Override
    public void update(boolean flag){
        if (flag) {
            this.vanish();
        }
    }

    public void generateSupply(List<AbstractSupply> supplys) {}

}
