package edu.hitsz.factory;

import edu.hitsz.aircraft.EliteEnemy;
import edu.hitsz.application.ImageManager;
import edu.hitsz.application.Main;

/**
 * @author wlx04
 */
public class EliteEnemyFactory implements EnemyAircraftFactory {
    public int hp = 30;
    public int power = 30;
    public int direction = 1;
    public int shootNum = 1;

    @Override
    public EliteEnemy createEnemyAircraft() {
        return new EliteEnemy((int) (Math.random() * (Main.WINDOW_WIDTH - ImageManager.MOB_ENEMY_IMAGE.getWidth())),
                (int) (Math.random() * Main.WINDOW_HEIGHT * 0.2),
                0,
                7,
                hp,
                shootNum,
                power,
                direction,
                false);
    }
}

