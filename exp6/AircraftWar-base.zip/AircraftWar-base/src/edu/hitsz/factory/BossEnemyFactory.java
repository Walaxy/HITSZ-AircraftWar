package edu.hitsz.factory;

import edu.hitsz.aircraft.BossEnemy;
import edu.hitsz.application.ImageManager;
import edu.hitsz.application.Main;

/**
 * @author wlx04
 */
public class BossEnemyFactory implements EnemyAircraftFactory {
    public static int hp = 100;
    public int power = 50;
    public int direction = 1;
    public int shootNum = 3;

    @Override
    public BossEnemy createEnemyAircraft() {
        return new BossEnemy((int) (Math.random() * (Main.WINDOW_WIDTH - ImageManager.MOB_ENEMY_IMAGE.getWidth())),
                0,
                5,
                0,
                hp,
                shootNum,
                power,
                direction,
                false);
    }


}
