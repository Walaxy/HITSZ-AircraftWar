package edu.hitsz.strategy;

import edu.hitsz.bullet.BaseBullet;

import java.util.List;

public interface ShootStrategy {
    /**
     * @param shootNum          子弹一次发射的数量
     * @param aircraftLocationX 飞机的X坐标
     * @param aircraftLocationY 飞机的Y坐标
     * @param aircraftSpeedY    飞机的Y速度
     * @param direction         子弹射击方向 (向上发射：-1，向下发射：1)
     * @param power             子弹伤害
     * @param isHero            是否为英雄机
     */

    List<BaseBullet> doShoot(int shootNum, int aircraftLocationX, int aircraftLocationY, int aircraftSpeedY, int direction, int power, boolean isHero );
}
