package edu.hitsz.application;

import javax.sound.sampled.*;
import javax.sound.sampled.DataLine.Info;
import java.io.*;

public class MusicThread extends Thread {


    //音频文件名
    private String filename;
    private AudioFormat audioFormat;
    private byte[] samples;
    private boolean isLoop;
    private boolean isStop;

    private InputStream inputStream;
    private SourceDataLine dataLine;

    public MusicThread(String filename) {
        //初始化filename
        this.filename = filename;
        reverseMusic();
        this.isLoop = true;
        this.isStop = false;

    }

    public void reverseMusic() {
        try {
            //定义一个AudioInputStream用于接收输入的音频数据，使用AudioSystem来获取音频的音频输入流
            AudioInputStream stream = AudioSystem.getAudioInputStream(new File(filename));
            //用AudioFormat来获取AudioInputStream的格式
            audioFormat = stream.getFormat();
            samples = getSamples(stream);
        } catch (UnsupportedAudioFileException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public byte[] getSamples(AudioInputStream stream) {
        int size = (int) (stream.getFrameLength() * audioFormat.getFrameSize());
        byte[] samples = new byte[size];
        DataInputStream dataInputStream = new DataInputStream(stream);
        try {
            dataInputStream.readFully(samples);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return samples;
    }

    public void play() {
        start();
    }

    @Override
    public void run() {
        try {
            inputStream = new ByteArrayInputStream(samples);
            int size = (int) (audioFormat.getFrameSize() * audioFormat.getSampleRate());
            byte[] buffer = new byte[size];
            Info info = new Info(SourceDataLine.class, audioFormat);
            dataLine = (SourceDataLine) AudioSystem.getLine(info);
            dataLine.open(audioFormat, size);
            dataLine.start();

            while (!isStop) {
                int numBytesRead = inputStream.read(buffer, 0, buffer.length);
                if (numBytesRead == -1) {
                    if (isLoop && !isStop) {
                        resetStream();
                    } else {
                        isStop = true;
                    }
                } else {
                    dataLine.write(buffer, 0, numBytesRead);
                }
            }

            inputStream.close();
            dataLine.drain();
            dataLine.stop();
            dataLine.close();
        } catch (IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }


    public void resetStream() {
        inputStream = new ByteArrayInputStream(samples);
    }

    public void setLoop(boolean isLoop) {
        this.isLoop = isLoop;
    }

    public boolean isLoop() {
        return this.isLoop;
    }

    public void stopPlaying() throws IOException {
        this.isStop = true;
        inputStream.close();
        dataLine.drain();
        dataLine.stop();
        dataLine.close();
    }

    public boolean isPlaying() {
        return !this.isStop;
    }
}


