package edu.hitsz.application;

import java.io.IOException;

public class EasyGame extends AbsractGame{
    public EasyGame(boolean isMusic) throws IOException {
        super(isMusic);
        this.difficulty = "Easy";
        this.BACKGROUND_IMAGE = ImageManager.EASY_BACKGROUND_IMAGE;
    }
    // 无boss
    // 难度不随时间++


    @Override
    protected boolean setGenerateBossOrNot() {
        return false;
    }//简单模式无boss


    @Override
    protected void setEnemycycleDuration() {
        this.enemycycleDuration = 600;
    }

    @Override
    protected void setHerocycleDuration(){
        this.herocycleDuration = 100;
    }

    @Override
    protected void setEnemyMaxNumber() {
        this.enemyMaxNumber = 3;
    }


    @Override
    protected void setEliteEnemyRate(){
        this.eliteEnemyRate = 0.8;//小于是mob, 大于是elite
    }

    @Override
    protected void setBossGenerateScore(){
        this.bossGenerateScore = 99999999;//反正不生成boss
    }

    @Override
    protected boolean setIsBossIncreaseHpBytime(){
        return false;
    }

    @Override
    protected boolean setIsImproveEnemyBytime(){
        return false;
    }

    @Override
    protected void increaseDifficulty() {}




}
