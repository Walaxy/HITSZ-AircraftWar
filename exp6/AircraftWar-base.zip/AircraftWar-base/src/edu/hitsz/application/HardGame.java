package edu.hitsz.application;

import edu.hitsz.factory.BossEnemyFactory;

import java.io.IOException;

public class HardGame extends AbsractGame{
    public HardGame(boolean isMusic) throws IOException {
        super(isMusic);
        this.difficulty = "Hard";
        this.BACKGROUND_IMAGE = ImageManager.HARD_BACKGROUND_IMAGE;
    }

    @Override
    protected boolean setGenerateBossOrNot() {
        return true;
    }


    @Override
    protected void setEnemycycleDuration() {
        this.enemycycleDuration = 200;
    }

    @Override
    protected void setHerocycleDuration() {
        this.herocycleDuration = 300;
    }

    @Override
    protected void setEnemyMaxNumber() {
        this.enemyMaxNumber = 5;
    }


    @Override
    protected void setEliteEnemyRate() {
        this.eliteEnemyRate = 0.4;//小于是mob, 大于是elite
    }

    @Override
    protected void setBossGenerateScore() {
        this.bossGenerateScore = 150;
    }

    @Override
    protected boolean setIsBossIncreaseHpBytime() {
        return true;//每次召唤的血量
    }

    @Override
    protected boolean setIsImproveEnemyBytime() {
        return true;//对局内随时间提升
    }

    @Override
    protected void increaseDifficulty() {


        if (this.enemycycleDuration > 150) {
            this.enemycycleDuration -= 5;
        }//最快是150

        if (this.eliteEnemyRate > 0.2) {
            this.eliteEnemyRate -= 0.01;
        }//最低是0.4

        if(this.bossGenerateScore >100 ){
            this.bossGenerateScore -= 0.5;
        }




        System.out.println("提升难度! Enemy生成时间: " + this.enemycycleDuration + ",  精英敌机生成概率: " + this.eliteEnemyRate
                +", Boss生成阈值: "+this.bossGenerateScore
        +", 下次召唤Boss血量: "+BossEnemyFactory.hp);

    }


}
