package edu.hitsz.application;

import java.io.IOException;

public class CommonGame extends AbsractGame {
    public CommonGame(boolean isMusic) throws IOException {
        super(isMusic);
        this.difficulty = "Common";
        this.BACKGROUND_IMAGE = ImageManager.COMMON_BACKGROUND_IMAGE;
    }


    @Override
    protected boolean setGenerateBossOrNot() {
        return true;
    }//简单模式无boss

    @Override
    protected void setEnemycycleDuration() {
        this.enemycycleDuration = 300;
    }

    @Override
    protected void setHerocycleDuration() {
        this.herocycleDuration = 200;
    }

    @Override
    protected void setEnemyMaxNumber() {
        this.enemyMaxNumber = 5;
    }


    @Override
    protected void setEliteEnemyRate() {
        this.eliteEnemyRate = 0.5;//小于是mob, 大于是elite
    }

    @Override
    protected void setBossGenerateScore() {
        this.bossGenerateScore = 200;
    }

    @Override
    protected boolean setIsBossIncreaseHpBytime() {
        return false;
    }

    @Override
    protected boolean setIsImproveEnemyBytime() {
        return true;
    }

    @Override
    protected void increaseDifficulty() {


        if (this.enemycycleDuration > 200) {
            this.enemycycleDuration -= 10;
        }//最快是200

        if (this.eliteEnemyRate > 0.4) {
            this.eliteEnemyRate -= 0.01;
        }//最低是0.4

        if(this.bossGenerateScore >180 ){
            this.bossGenerateScore -= 0.5;
        }


        System.out.println("提升难度! Enemy生成时间: " + this.enemycycleDuration + ",  精英敌机生成概率: " + this.eliteEnemyRate
        +", Boss生成阈值: "+this.bossGenerateScore);

    }
}
