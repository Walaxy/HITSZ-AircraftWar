package edu.hitsz.application;



import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.Objects;
/**
 * 程序入口
 *
 * @author hitsz
 */
public class Main {

    public static final int WINDOW_WIDTH = 512;
    public static final int WINDOW_HEIGHT = 768;
    public static final Object MAIN_LOCK = new Object();
    public static AbsractGame game;
    public static AbsractGame game2;
    public static ScoreTable scoreTable;

    public static StartMenu startMenu = new StartMenu();

    public static void main(String[] args) throws IOException {

        System.out.println("Hello Aircraft War");

        // 获得屏幕的分辨率，初始化 Frame
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        JFrame frame = new JFrame("Aircraft War");

        frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        frame.setResizable(false);
        //设置窗口的大小和位置,居中放置
        frame.setBounds(((int) screenSize.getWidth() - WINDOW_WIDTH) / 2, 0,
                WINDOW_WIDTH, WINDOW_HEIGHT);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 第一个界面
        //选择难度和音效
        JPanel startMenuPanel = startMenu.getMainPanel();
        frame.setContentPane(startMenuPanel);
        frame.setVisible(true);
        // 检测StartMenu是否结束
        synchronized (MAIN_LOCK) {
            while (startMenuPanel.isVisible()) {
                // 主线程等待开始面板关闭
                try {
                    MAIN_LOCK.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        frame.remove(startMenuPanel);
        // 第二个界面
        if (Objects.equals(startMenu.difficulty, "Easy")) {
            game = new EasyGame(startMenu.isMusic);
        } else if (Objects.equals(startMenu.difficulty, "Common")) {
            game = new CommonGame(startMenu.isMusic);
        } else if (Objects.equals(startMenu.difficulty, "Hard")){
            game = new HardGame(startMenu.isMusic);
        }
        game2 = game;
        frame.setContentPane(game);
        frame.setVisible(true);
        game.action();


        //System.out.println(game.isVisible());
        // 检测游戏是否结束
        synchronized (MAIN_LOCK) {
            while (game.isVisible()) {
                // 主线程等待游戏面板关闭
                try {
                    MAIN_LOCK.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        frame.remove(game);
        scoreTable = new ScoreTable(game2);
        JPanel scoreTablePanel = scoreTable.getMainPanel();
        frame.setContentPane(scoreTablePanel);
        frame.setVisible(true);






    }
}
