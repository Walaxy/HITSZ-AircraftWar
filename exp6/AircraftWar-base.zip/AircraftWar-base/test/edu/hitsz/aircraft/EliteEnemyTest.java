package edu.hitsz.aircraft;

import edu.hitsz.application.ImageManager;
import edu.hitsz.application.Main;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class EliteEnemyTest {

    private EliteEnemy eliteEnemy;

    @BeforeAll
    static void beforeAll() {
        System.out.println("**--- Executed once before all test methods in this class ---**");
    }

    @BeforeEach
    void setUp() {
        System.out.println("**--- Executed before each test method in this class ---**");
        eliteEnemy = new EliteEnemy(Main.WINDOW_WIDTH / 2,
                Main.WINDOW_HEIGHT - ImageManager.ELITE_ENEMY_IMAGE.getHeight(),
                0,
                10,
                30);
    }

    @AfterEach
    void tearDown() {
        System.out.println("**--- Executed after each test method in this class ---**");
        eliteEnemy = null;
    }


    @DisplayName("Test getScoreAward method")
    @Test
    void getScoreAward() {
        System.out.println("**--- Test getScoreAward method executed ---**");
        int award = eliteEnemy.getScoreAward();
        assertEquals(50, award);
    }


    @DisplayName("Test forward method")
    @Test
    void forward() {
        System.out.println("**--- Test forward method executed ---**");
        eliteEnemy.setLocation(eliteEnemy.getLocationX(), edu.hitsz.application.Main.WINDOW_HEIGHT + 1);
        eliteEnemy.forward();
        assertFalse(eliteEnemy.isValid);
    }
}