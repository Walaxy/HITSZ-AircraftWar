package edu.hitsz.aircraft;

import edu.hitsz.Supply.AbstractSupply;
import edu.hitsz.application.Main;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.HeroBullet;
import edu.hitsz.factory.BombSupplyFactory;
import edu.hitsz.factory.FireSupplyFactory;
import edu.hitsz.factory.HealingSupplyFactory;
import edu.hitsz.factory.SupplyFactory;

import java.util.LinkedList;
import java.util.List;

/**
 * 精英敌机
 * 按设定周期射击
 * 坠毁后会随机产生某种道具(向下飞行)/or不产生
 *
 * @author caphhh
 */


public class EliteEnemy extends AbstractAircraft {
    private int shootNum = 1;//子弹一次的发射数量
    private int power = 30;//子弹伤害
    /**
     * 子弹射击方向 (向上发射：1，向下发射：-1)
     */
    private int direction = 1;//精英机和英雄机方向相反

    /**
     * @param locationX 精英机位置x坐标
     * @param locationY 精英机位置y坐标
     * @param speedX    精英机射出的子弹的基准速度（精英机无特定速度）
     * @param speedY    精英机射出的子弹的基准速度（精英机无特定速度）
     * @param hp        初始生命值
     */
    public EliteEnemy(int locationX, int locationY, int speedX, int speedY, int hp) {
        super(locationX, locationY, speedX, speedY, hp);
    }

    @Override
    public void forward() {
        super.forward();
        // 判定 y 轴向下飞行出界
        if (locationY >= Main.WINDOW_HEIGHT) {
            vanish();
        }
    }//来自MobEnemy

    @Override
    /**
     * 通过射击产生子弹
     * @return 射击出的子弹List
     */
    public List<BaseBullet> shoot() {
        List<BaseBullet> res = new LinkedList<>();
        int x = this.getLocationX();
        int y = this.getLocationY() + direction * 2;
        int speedX = 0;
        int speedY = this.getSpeedY() + direction * 5;
        BaseBullet bullet;
        for (int i = 0; i < shootNum; i++) {
            // 子弹发射位置相对飞机位置向前偏移
            // 多个子弹横向分散
            bullet = new HeroBullet(x + (i * 2 - shootNum + 1) * 10, y, speedX, speedY, power);
            res.add(bullet);
        }
        return res;
    }//来自HeroAircraft

    /**
     * 实现"随机产生道具"
     * 通过Math类的random()方法，它可以生成一个[0.0, 1.0)之间的伪随机数
     */


    public void generateSupply(List<AbstractSupply> supplys) {
        SupplyFactory supplyfactory;
        double rate = Math.random();
        if (rate > 0.9) {
            // 不产生随机道具
            return;
        } else if (rate > 0.6) {
            supplyfactory = new BombSupplyFactory();
            //System.out.println("产生bomb");
        } else if (rate > 0.3) {
            supplyfactory = new HealingSupplyFactory();
            //System.out.println("产生healing");
        } else {
            supplyfactory = new FireSupplyFactory();
            //System.out.println("产生fire");
        }
        supplys.add(supplyfactory.createSupply(locationX, locationY, 0, 5));
    }


}
