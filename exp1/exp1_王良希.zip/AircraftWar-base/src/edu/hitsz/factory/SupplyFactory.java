package edu.hitsz.factory;

import edu.hitsz.Supply.AbstractSupply;

public interface SupplyFactory {

    AbstractSupply createSupply(int locationX, int locationY, int speedX, int speedY);

}
