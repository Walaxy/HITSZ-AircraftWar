package edu.hitsz.factory;

import edu.hitsz.Supply.AbstractSupply;
import edu.hitsz.Supply.BombSupply;

public class BombSupplyFactory implements SupplyFactory{

    @Override
    public AbstractSupply createSupply(int locationX, int locationY, int speedX, int speedY) {
        return new BombSupply(locationX, locationY, speedX, 5);
    }
}
