package edu.hitsz.factory;

import edu.hitsz.Supply.AbstractSupply;
import edu.hitsz.Supply.FireSupply;

public class FireSupplyFactory implements SupplyFactory{

    @Override
    public AbstractSupply createSupply(int locationX, int locationY, int speedX, int speedY) {
        return new FireSupply(locationX, locationY, speedX, 5);
    }
}
