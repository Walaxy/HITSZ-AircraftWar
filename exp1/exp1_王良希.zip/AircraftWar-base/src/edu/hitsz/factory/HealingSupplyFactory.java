package edu.hitsz.factory;

import edu.hitsz.Supply.AbstractSupply;
import edu.hitsz.Supply.HealingSupply;

public class HealingSupplyFactory implements SupplyFactory{

        @Override
        public AbstractSupply createSupply(int locationX, int locationY, int speedX, int speedY) {
            return new HealingSupply(locationX, locationY, speedX, 5);
        }

}