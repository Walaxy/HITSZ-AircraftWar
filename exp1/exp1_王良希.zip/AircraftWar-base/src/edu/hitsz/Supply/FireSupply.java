package edu.hitsz.Supply;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.application.Main;
import edu.hitsz.bullet.BaseBullet;

import java.util.List;

public class FireSupply extends AbstractSupply {


    public FireSupply(int locationX, int locationY, int speedX, int speedY) {
        super(locationX, locationY, speedX, speedY);
    }

    /**
     * public FireSupply create(){
     * return new FireSupply(this.locationX, this.locationY, this.speedX , 20);
     * }
     */

    @Override
    public void activate(HeroAircraft heroAircraft, List<BaseBullet> enemyBullets, List<AbstractAircraft> enemyAircrafts) {
        System.out.println("FireSupply active!");

    }

    @Override
    public void forward() {
        super.forward();
        // 判定 y 轴向下飞行出界
        if (locationY >= Main.WINDOW_HEIGHT) {
            vanish();
        }
    }


}
