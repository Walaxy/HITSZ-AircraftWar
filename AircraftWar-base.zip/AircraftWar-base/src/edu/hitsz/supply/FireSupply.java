package edu.hitsz.supply;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.application.Main;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.strategy.DirectShootStrategy;
import edu.hitsz.strategy.ScatterShootStrategy;

import java.util.List;

/**
 * @author wlx04
 */
public class FireSupply extends edu.hitsz.supply.AbstractSupply {


    public FireSupply(int locationX, int locationY, int speedX, int speedY) {
        super(locationX, locationY, speedX, speedY);
    }


    @Override
    public void activate(HeroAircraft heroAircraft, List<BaseBullet> enemyBullets, List<AbstractAircraft> enemyAircrafts) {
        System.out.println("FireSupply active!");


        Runnable r1 = () ->{
            heroAircraft.shootNum+=2;
            heroAircraft.setShootStrategy(new ScatterShootStrategy());
        };
        Thread thread1 = new Thread(r1);
        thread1.start();

        Runnable r2 = () ->{
            try {
                thread1.join();
                Thread.sleep(3000);//3秒
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            heroAircraft.shootNum=1;
            heroAircraft.setShootStrategy(new DirectShootStrategy());
        };
        Thread thread2 = new Thread(r2);
        thread2.start();


    }

    @Override
    public void forward() {
        super.forward();
        // 判定 y 轴向下飞行出界
        if (locationY >= Main.WINDOW_HEIGHT) {
            vanish();
        }
    }


}
