package edu.hitsz.record;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class FileParser {
    private static final String FILE_PATH = "src/edu/hitsz/record/sorted-record.txt";
    private String[][] tableData;

    public FileParser() {
        ArrayList<String[]> dataList = new ArrayList<>();
        File file = new File(FILE_PATH);

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = parseLine(line);
                if (data != null) {
                    dataList.add(data);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        tableData = dataList.toArray(new String[0][]);
    }

    public String[][] getTableData() {
        return this.tableData;
    }

    private static String[] parseLine(String line) {
        String[] data = new String[4];
        String[] parts1 = line.split(",");
        if (parts1.length != 4) {
            return null;
        }
        data[0] = parts1[0].substring(1, parts1[0].length() - 2); // 第9名 -> 9
        String[] parts2 = parts1[1].split(":");
        if (parts2.length != 2) {
            return null;
        }
        data[1] = parts2[1]; // Username:wlx -> wlx
        String[] parts3 = parts1[2].split(":");
        if (parts3.length != 2) {
            return null;
        }
        data[2] = parts3[1]; // Time:2023-04-12 12:04:50 -> 2023-04-12 12:04:50
        String[] parts4 = parts1[3].split(":");
        if (parts4.length != 2) {
            return null;
        }
        data[3] = parts4[1]; // Score:0.00 -> 0.00
        return data;
    }
    public static void main(String[] args) {
        FileParser parser = new FileParser();
        String[][] tableData = parser.getTableData();
        // 将tableData传递给 ScoreTable 中的表格构造函数


    }
}