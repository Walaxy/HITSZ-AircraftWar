package edu.hitsz.strategy;

import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.EnemyBullet;
import edu.hitsz.bullet.HeroBullet;

import java.util.LinkedList;
import java.util.List;

public class DirectShootStrategy implements ShootStrategy {
    @Override
    public List<BaseBullet> doShoot(int shootNum, int aircraftLocationX, int aircraftLocationY, int aircraftSpeedY, int direction, int power, boolean isHero) {
        List<BaseBullet> res = new LinkedList<>();

        int y = aircraftLocationY + direction * 2;
        int speedX = 0;
        int speedY = aircraftSpeedY + direction * 5;
        BaseBullet bullet;
        for(int i = 0;i<shootNum;i++){
            int x = aircraftLocationX + (i * 2 - shootNum + 1) * 10;//横向分散
            if(isHero){
                bullet = new HeroBullet(x,y,speedX,speedY,power);
            }else{
                bullet = new EnemyBullet(x,y,speedX,speedY,power);
            }
            res.add(bullet);
        }
        return res;
    }



}
