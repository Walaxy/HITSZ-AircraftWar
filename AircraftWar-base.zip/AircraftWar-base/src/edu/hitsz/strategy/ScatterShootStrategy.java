package edu.hitsz.strategy;

import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.EnemyBullet;
import edu.hitsz.bullet.HeroBullet;

import java.util.LinkedList;
import java.util.List;

public class ScatterShootStrategy implements ShootStrategy {
    @Override
    public List<BaseBullet> doShoot(int shootNum, int aircraftLocationX, int aircraftLocationY, int aircraftSpeedY, int direction, int power, boolean isHero) {
        List<BaseBullet> res = new LinkedList<>();

        int y = aircraftLocationY + direction * 2;

        int speedY = aircraftSpeedY + direction * 5;

        for (int i = 0;i<shootNum;i++){
            int x = aircraftLocationX + (i * 2 - shootNum + 1) * 10;//横向分散
            int speedX = i * 2 - shootNum + 1;//实现扇形
            if(isHero){
                res.add(new HeroBullet(x,y,speedX,speedY,power));
            }else{
                res.add(new EnemyBullet(x,y,speedX,speedY,power));
            }
        }

        return res;
    }
}
