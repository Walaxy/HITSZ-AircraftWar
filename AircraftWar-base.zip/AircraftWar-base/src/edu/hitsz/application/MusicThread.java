package edu.hitsz.application;

import javax.sound.sampled.*;
import javax.sound.sampled.DataLine.Info;
import java.io.*;

public class MusicThread extends Thread {


    //音频文件名
    private String filename;
    private AudioFormat audioFormat;
    private byte[] samples;
    private boolean isLoop;
    private boolean isStop;

    private InputStream inputStream;
    private SourceDataLine dataLine;

    public MusicThread(String filename) {
        //初始化filename
        this.filename = filename;
        reverseMusic();
        this.isLoop = true;
        this.isStop = false;

    }

    public void reverseMusic() {
        try {
            //定义一个AudioInputStream用于接收输入的音频数据，使用AudioSystem来获取音频的音频输入流
            AudioInputStream stream = AudioSystem.getAudioInputStream(new File(filename));
            //用AudioFormat来获取AudioInputStream的格式
            audioFormat = stream.getFormat();
            samples = getSamples(stream);
        } catch (UnsupportedAudioFileException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public byte[] getSamples(AudioInputStream stream) {
        int size = (int) (stream.getFrameLength() * audioFormat.getFrameSize());
        byte[] samples = new byte[size];
        DataInputStream dataInputStream = new DataInputStream(stream);
        try {
            dataInputStream.readFully(samples);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return samples;
    }

    public void play() {
        int size = (int) (audioFormat.getFrameSize() * audioFormat.getSampleRate());
        byte[] buffer = new byte[size];
        Info info = new Info(SourceDataLine.class, audioFormat);
        try {
            dataLine = (SourceDataLine) AudioSystem.getLine(info);
            dataLine.open(audioFormat, size);
        } catch (LineUnavailableException e) {
            e.printStackTrace();
        }
        dataLine.start();
        if (inputStream == null) {
            resetStream();
        }
        while (!isStop) {
            try {
                int numBytesRead = 0;
                while (numBytesRead != -1) {
                    while ((!isStop) && (numBytesRead = inputStream.read(buffer, 0, buffer.length)) != -1) {
                        dataLine.write(buffer, 0, numBytesRead);
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            if (isLoop && !isStop) {
                resetStream();
            }
        }
        dataLine.close();
    }

    @Override
    public void run() {
        InputStream stream = new ByteArrayInputStream(samples);
        play();
    }

    public void resetStream() {
        inputStream = new ByteArrayInputStream(samples);
    }

    public void setLoop(boolean isLoop) {
        this.isLoop = isLoop;
    }

    public boolean isLoop() {
        return this.isLoop;
    }

    public void stopPlaying() {
        this.isStop = true;
    }

    public boolean isPlaying() {
        return !this.isStop;
    }
}


