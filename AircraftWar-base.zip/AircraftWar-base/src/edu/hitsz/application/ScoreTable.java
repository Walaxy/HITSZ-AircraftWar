package edu.hitsz.application;

import edu.hitsz.record.record;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import edu.hitsz.record.record;
import edu.hitsz.record.recordDao;
import edu.hitsz.record.recordDaoImpl;



public class ScoreTable {
    private JPanel mainPanel;
    private JPanel topPanel;
    private JPanel bottomPanel;

    private JLabel nameLabel;
    private JScrollPane scoreScrollPanel;
    private JTable scoreTable;
    private JButton deleteButton;
    private JLabel diffiLabel;
    private static String UserName;
    private final recordDao recorddao = new recordDaoImpl();

    public ScoreTable(AbsractGame game) {
        String input = JOptionPane.showInputDialog(mainPanel, "Score:" + game.score + "，请输入用户名", "test");
        if (!Objects.equals(input, "")) {
            game.UserName = input;
            //System.out.println("ScoreTable中UserName: "+game.UserName);
        }
        diffiLabel.setText(game.difficulty);

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String Systime = now.format(formatter);
        int lineNum =  recorddao.getRecordNum();
        record newRecord = new record(game.UserName  , Systime, game.score, lineNum);
        recorddao.doAdd(newRecord);
        recorddao.fileWriter();
        game.sortRecord();
        game.readFromFileAndPrint();



        String[] columnName = {"名次", "玩家名", "时间", "成绩"};

        ArrayList<String[]> dataList = new ArrayList<>();
        String FILE_PATH = null;
        //根据难度选择文件
        if(Objects.equals(game.difficulty, "Easy")){
            FILE_PATH = "src/edu/hitsz/record/sorted-easy-record.txt";
        }
        else if(Objects.equals(game.difficulty, "Common")){
            FILE_PATH = "src/edu/hitsz/record/sorted-common-record.txt";
        }
        else if(Objects.equals(game.difficulty, "Hard")){
            FILE_PATH = "src/edu/hitsz/record/sorted-hard-record.txt";
        }
        File file = null;
        if (FILE_PATH != null) {
            file = new File(FILE_PATH);
        }

        if (file != null) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = parseLine(line);
                    if (data != null) {
                        dataList.add(data);

                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        String[][] tableData = dataList.toArray(new String[0][]);


        DefaultTableModel model = new DefaultTableModel(tableData, columnName) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        scoreTable.setModel(model);
        scoreScrollPanel.setViewportView(scoreTable);


        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int row = scoreTable.getSelectedRow();
                System.out.println(row);
                int result = JOptionPane.showConfirmDialog(deleteButton,
                        "是否确定中删除？");
                if (JOptionPane.YES_OPTION == result && row != -1) {
                    model.removeRow(row);
                }
            }

        });
    }

    public JPanel getMainPanel() {
        return mainPanel;
    }

    public static void main(String[] args) {
        //获取FileParser中的tableData

        JFrame frame = new JFrame("ScoreTable");


    }

    private static String[] parseLine(String line) {
        String pattern = "第(\\d+)名,Username:(\\w+),Time:(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}),Score:(\\d+)";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(line);

        if (m.find()) {
            String[] result = new String[4];
            result[0] = m.group(1);    // 提取第几名
            result[1] = m.group(2);    // 提取用户名
            result[2] = m.group(3);    // 提取时间
            result[3] = m.group(4);    // 提取分数
            //System.out.println(Arrays.toString(result));
            return result;
        } else {
            return null;
        }
    }
    public static String getUserName(){
        return UserName;
    }
}
