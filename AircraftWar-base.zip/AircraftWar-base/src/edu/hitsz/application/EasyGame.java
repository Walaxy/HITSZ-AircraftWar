package edu.hitsz.application;

import java.io.IOException;

public class EasyGame extends AbsractGame{
    public EasyGame(boolean isMusic) throws IOException {
        super(isMusic);
        this.difficulty = "Easy";
        this.BACKGROUND_IMAGE = ImageManager.EASY_BACKGROUND_IMAGE;
    }
}
