package edu.hitsz.application;

import java.io.IOException;

public class HardGame extends AbsractGame{
    public HardGame(boolean isMusic) throws IOException {
        super(isMusic);
        this.difficulty = "Hard";
        this.BACKGROUND_IMAGE = ImageManager.HARD_BACKGROUND_IMAGE;
    }
}
