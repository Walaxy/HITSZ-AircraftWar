package edu.hitsz.application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Objects;

import static edu.hitsz.application.Main.*;

public class StartMenu {
    private JPanel difficultyPanel;
    private JPanel main;
    private JPanel mainPanel;
    private JPanel gamePanel;
    public static boolean isMusic = true;
    public  String difficulty;
    private JPanel musicPanel;
    private JButton EasyButton;
    private JButton HardButton;
    private JButton CommonButton;
    private JLabel MusicLabel;
    private JComboBox MusiccomboBox;


    public StartMenu() {




        EasyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Easy模式");
                startMenu.difficulty = "Easy";
                mainPanel.setVisible(false);
                synchronized (MAIN_LOCK) {
                    // 选定难度，通知主线程结束
                    MAIN_LOCK.notify();
                }
            }
        });
        CommonButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Common模式");
                difficulty = "Common";
                mainPanel.setVisible(false);
                synchronized (MAIN_LOCK) {
                    // 选定难度，通知主线程结束
                    MAIN_LOCK.notify();
                }

            }
        });
        HardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Hard模式");
                difficulty = "Hard";
                mainPanel.setVisible(false);
                synchronized (MAIN_LOCK) {
                    // 选定难度，通知主线程结束
                    MAIN_LOCK.notify();
                }
            }
        });

        MusiccomboBox.addItem("开");
        MusiccomboBox.addItem("关");

        MusiccomboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (MusiccomboBox.getSelectedItem().equals("开")) {
                    System.out.println("开");
                    isMusic = true;
                } else if (MusiccomboBox.getSelectedItem().equals("关")) {
                    System.out.println("关");
                    isMusic = false;
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("DifficultyChoose");
        frame.setContentPane(new StartMenu().mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public JPanel getMainPanel() {
        return mainPanel;
    }

    private void switchToGamePanel() throws IOException {
        // 执行 difficulty 的判断，创建对应的游戏面板
        System.out.println("切换到游戏面板");
        if (Objects.equals(startMenu.difficulty, "Easy")) {
            game = new EasyGame(startMenu.isMusic);
            // ...
        } else if (Objects.equals(startMenu.difficulty, "Common")) {
            game = new CommonGame(startMenu.isMusic);
            // ...
        } else if (Objects.equals(startMenu.difficulty, "Hard")) {
            game = new HardGame(startMenu.isMusic);
            // ...
        }

    }
    public  String getMusicStatus() {
        return (String) MusiccomboBox.getSelectedItem();
    }

}
