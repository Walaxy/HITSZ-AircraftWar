package edu.hitsz.application;

import java.io.IOException;

public class CommonGame extends AbsractGame {
    public CommonGame(boolean isMusic) throws IOException {
        super(isMusic);
        this.difficulty = "Common";
        this.BACKGROUND_IMAGE = ImageManager.COMMON_BACKGROUND_IMAGE;
    }
}
