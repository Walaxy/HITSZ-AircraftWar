package edu.hitsz.supply;

import edu.hitsz.application.ImageManager;
import edu.hitsz.application.Main;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

class HealingSupplyTest {
    private HealingSupply healingSupply;

    @BeforeAll
    static void beforeAll() {
        System.out.println("**--- Executed once before all test methods in this class ---**");
    }

    @BeforeEach
    void setUp() {
        System.out.println("**--- Executed before each test method in this class ---**");
        healingSupply = new HealingSupply(Main.WINDOW_WIDTH / 2,
                Main.WINDOW_HEIGHT - ImageManager.HEALING_SUPPLY_IMAGE.getHeight(),
                0,
                5);//设置位置 随机 类似英雄机
    }

    @AfterEach
    void tearDown() {
        System.out.println("**--- Executed after each test method in this class ---**");
        healingSupply = null;
    }

    @DisplayName("Test getSpeedY method")
    @Test
    void getSpeedY() {
        System.out.println("**--- Test getSpeedY method executed ---**");
        int speedY = healingSupply.getSpeedY();
        assertEquals(5, speedY);
    }

    @DisplayName("Test getHealingAmount method")
    @Test
    void getHealingAmount() {
        System.out.println("**--- Test getHealingAmount method executed ---**");
        int healingAmount = healingSupply.getHealingAmount();
        assertEquals(500, healingAmount);
    }
}