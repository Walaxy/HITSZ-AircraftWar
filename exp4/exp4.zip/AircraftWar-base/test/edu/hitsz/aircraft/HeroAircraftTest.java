package edu.hitsz.aircraft;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class HeroAircraftTest {

    private HeroAircraft heroAircraft = HeroAircraft.getHeroAircraftInstance();


    @BeforeAll
    static void beforeAll() {
        System.out.println("**--- Executed once before all test methods in this class ---**");
    }

    @BeforeEach
    void setUp() {
        System.out.println("**--- Executed before each test method in this class ---**");

        //HeroAircraft instance = HeroAircraft.getHeroAircraftInstance();
    }

    @AfterEach
    void tearDown() {
        System.out.println("**--- Executed after each test method in this class ---**");
        heroAircraft = null;
    }

    @DisplayName("Test getHeroAircraftInstance method")
    @Test
    void getHeroAircraftInstance() {
        System.out.println("**--- Test getHeroAircraftInstance method executed ---**");
        HeroAircraft instance = HeroAircraft.getHeroAircraftInstance();
        assertNotNull(instance);
        assertEquals(heroAircraft, instance);
    }

    @DisplayName("Test getHp method")
    @Test
    void decreaseHp() {
        System.out.println("**--- Test decreaseHp method executed ---**");
        int decrease1 = 30;
        int expected1 = heroAircraft.getHp() - decrease1;
        int decrease2 = -300;
        int expected2 = heroAircraft.maxHp;//分支测试
        heroAircraft.decreaseHp(decrease1);
        assertEquals(expected1, heroAircraft.getHp());
        heroAircraft.decreaseHp(decrease2);
        assertEquals(expected2, heroAircraft.getHp());
    }

    
}