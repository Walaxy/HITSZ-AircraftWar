package edu.hitsz.supply;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.application.Main;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.strategy.ScatterShootStrategy;

import java.util.List;

/**
 * @author wlx04
 */
public class FireSupply extends edu.hitsz.supply.AbstractSupply {


    public FireSupply(int locationX, int locationY, int speedX, int speedY) {
        super(locationX, locationY, speedX, speedY);
    }


    @Override
    public void activate(HeroAircraft heroAircraft, List<BaseBullet> enemyBullets, List<AbstractAircraft> enemyAircrafts) {
        System.out.println("FireSupply active!");
        if(heroAircraft.shootNum < 5) {
            heroAircraft.shootNum += 1;//每生效一个fireSupply, 射击数量+1, 最多5个
        }
        heroAircraft.setShootStrategy(new ScatterShootStrategy());


    }

    @Override
    public void forward() {
        super.forward();
        // 判定 y 轴向下飞行出界
        if (locationY >= Main.WINDOW_HEIGHT) {
            vanish();
        }
    }


}
