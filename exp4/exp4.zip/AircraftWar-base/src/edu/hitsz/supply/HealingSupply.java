package edu.hitsz.supply;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.application.Main;
import edu.hitsz.bullet.BaseBullet;

import java.util.List;

/**
 * @author wlx04
 */
public class HealingSupply extends AbstractSupply {

    private final int HealingAmount = 500;

    public HealingSupply(int locationX, int locationY, int speedX, int speedY) {
        super(locationX, locationY, speedX, speedY);
    }

    @Override
    public void activate(HeroAircraft heroAircraft, List<BaseBullet> enemyBullets, List<AbstractAircraft> enemyAircrafts) {
        heroAircraft.decreaseHp(-this.HealingAmount);
        //System.out.println("active Healing supply!");
    }


    public int getHealingAmount() {
        return this.HealingAmount;
    }

    @Override
    public void forward() {
        super.forward();
        // 判定 y 轴向下飞行出界
        if (locationY >= Main.WINDOW_HEIGHT) {
            vanish();
        }
    }


}
