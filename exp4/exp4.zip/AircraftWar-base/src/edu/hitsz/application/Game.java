package edu.hitsz.application;

import edu.hitsz.aircraft.*;
import edu.hitsz.basic.AbstractFlyingObject;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.factory.BossEnemyFactory;
import edu.hitsz.factory.EliteEnemyFactory;
import edu.hitsz.factory.EnemyAircraftFactory;
import edu.hitsz.factory.MobEnemyFactory;
import edu.hitsz.record.record;
import edu.hitsz.record.recordDao;
import edu.hitsz.record.recordDaoImpl;
import edu.hitsz.supply.AbstractSupply;
import edu.hitsz.supply.BombSupply;
import edu.hitsz.supply.FireSupply;
import edu.hitsz.supply.HealingSupply;
import org.apache.commons.lang3.concurrent.BasicThreadFactory;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 游戏主面板，游戏启动
 *
 * @author hitsz
 */
public class Game extends JPanel {

    private int backGroundTop = 0;

    /**
     * Scheduled 线程池，用于任务调度
     */
    private final ScheduledExecutorService executorService;

    /**
     * 时间间隔(ms)，控制刷新频率
     */
    private final int timeInterval = 40;

    private final HeroAircraft heroAircraft;
    private final List<AbstractAircraft> enemyAircrafts;
    private final List<BaseBullet> heroBullets;
    private final List<BaseBullet> enemyBullets;
    private final List<AbstractSupply> supplys;
    private final recordDao recorddao;
    //private final recordDaoImpl recordDao;

    private final String UserName = "wlx";
    /**
     * 屏幕中出现的敌机最大数量
     */
    private int enemyMaxNumber = 5;

    /**
     * 当前得分
     */
    private int score = 0;
    /**
     * 当前时刻
     */
    private int time = 0;
    private Date nowTime = new Date();

    /**
     * 周期（ms)
     * 指示子弹的发射、敌机的产生频率
     */
    private int cycleDuration = 600;
    private int cycleTime = 0;

    private EnemyAircraftFactory enemyAircraftFactory;
    private EliteEnemyFactory eliteEnemyFactory;
    /**
     * 游戏结束标志
     */
    private boolean gameOverFlag = false;
    private int bossGenerateScore = 100;//boss机产生需要的分数, 即每多少分产生一次boss机
    private boolean isBossAlive = false;//boss机是否存活, 如果存活, 并且分数又+xx分, 则不再产生boss机
    private int bossGetScore = 0;//累计的分数, 产生boss机后, boss_score_get = 0


    public Game() {
        /*
         heroAircraft = new HeroAircraft(
         Main.WINDOW_WIDTH / 2,
         Main.WINDOW_HEIGHT - ImageManager.HERO_IMAGE.getHeight(),
         0, 0, 1000);*/
        heroAircraft = HeroAircraft.getHeroAircraftInstance();//todo √ 单例模式实现

        enemyAircrafts = new LinkedList<>();
        heroBullets = new LinkedList<>();
        enemyBullets = new LinkedList<>();
        supplys = new LinkedList<>();

        recorddao = new recordDaoImpl();


        /**
         * Scheduled 线程池，用于定时任务调度
         * 关于alibaba code guide：可命名的 ThreadFactory 一般需要第三方包
         * apache 第三方库： org.apache.commons.lang3.concurrent.BasicThreadFactory
         */
        this.executorService = new ScheduledThreadPoolExecutor(1,
                new BasicThreadFactory.Builder().namingPattern("game-action-%d").daemon(true).build());

        //启动英雄机鼠标监听
        new HeroController(this, heroAircraft);

    }

    /**
     * 游戏启动入口，执行游戏逻辑
     */
    public void action() {

        // 定时任务：绘制、对象产生、碰撞判定、击毁及结束判定
        Runnable task = () -> {

            time += timeInterval;

            // 周期性执行（控制频率）
            if (timeCountAndNewCycleJudge()) {
                System.out.println(time);
                // 新敌机产生

                if (enemyAircrafts.size() < enemyMaxNumber) {
                    double rateBetweenMobAndElite = Math.random();
                    if (rateBetweenMobAndElite < 0.6) {
                        enemyAircraftFactory = new MobEnemyFactory();
                        enemyAircrafts.add(enemyAircraftFactory.createEnemyAircraft());
                    } else {
                        enemyAircraftFactory = new EliteEnemyFactory();
                        enemyAircrafts.add(enemyAircraftFactory.createEnemyAircraft());
                    }
                }

                if (bossGetScore >= bossGenerateScore && !isBossAlive) {
                    enemyAircraftFactory = new BossEnemyFactory();
                    enemyAircrafts.add(enemyAircraftFactory.createEnemyAircraft());
                    //boss_get_score = 0;
                    isBossAlive = true;

                }
                // 飞机射出子弹
                shootAction();
            }
            ;

            // 子弹移动
            bulletsMoveAction();

            // 飞机移动
            aircraftsMoveAction();

            //道具移动
            supplyMoveAction();

            // 撞击检测
            crashCheckAction();

            // 后处理
            postProcessAction();

            //每个时刻重绘界面
            repaint();

            //道具碰撞检测以及生效
            //调用SupplyGotoWork方法
            supplyGotoWork();

            int recordId = 0;
            // 游戏结束检查英雄机是否存活
            if (heroAircraft.getHp() <= 0) {
                // 游戏结束
                executorService.shutdown();
                // todo 保存分数记录
                LocalDateTime now = LocalDateTime.now();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                String Systime = now.format(formatter);
                int lineNum =  recorddao.getRecordNum();
                record newRecord = new record(UserName, Systime, score, lineNum);
                recorddao.doAdd(newRecord);
                recorddao.fileWriter();
                gameOverFlag = true;

                //todo 打印分数记录
                System.out.println("***********************");
                System.out.println("      打印分数记录");
                System.out.println("***********************");
                sortRecord();
                readFromFileAndPrint();
                System.out.println("Game Over!");
            }

        };

        /*
          以固定延迟时间进行执行
          本次任务执行完成后，需要延迟设定的延迟时间，才会执行新的任务
         */
        executorService.scheduleWithFixedDelay(task, timeInterval, timeInterval, TimeUnit.MILLISECONDS);


    }
    //从排序后的文件中读取并打印
    public void readFromFileAndPrint(){
        //System.out.println("读取文件内容：???");
        String fileName = "src/edu/hitsz/record/sorted-record.txt";

        try {
            //创建FileReader对象，用于读取文件
            FileReader fileReader = new FileReader(fileName);

            //创建BufferedReader对象，用于每次读取一行数据
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            //读取文件的每一行，直到文件结束
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);

            }

            //关闭bufferedReader对象
            bufferedReader.close();
        } catch (IOException e) {
            System.out.println("读取文件时出现错误：" + e.getMessage());
        }
        //System.out.println("打印文件内容结束。");

    }
    //对record.txt排序
    public void sortRecord(){
        // 指定要读取的文件路径和文件名
        String inputFileName = "src/edu/hitsz/record/record.txt";

        // 指定要写入的文件路径和文件名
        String outputFileName = "src/edu/hitsz/record/sorted-record.txt";

        try {
            // 读取文件内容，将每一行记录存储到List中
            List<String> recordList = new ArrayList<String>();
            FileReader fileReader = new FileReader(inputFileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                recordList.add(line);
            }
            bufferedReader.close();

            // 对记录进行排序，按照分数Score进行降序排序
            recordList.sort(new Comparator<String>() {
                @Override
                public int compare(String o1, String o2) {
                    int score1 = Integer.parseInt(o1.substring(o1.lastIndexOf("Score:") + 6));
                    int score2 = Integer.parseInt(o2.substring(o2.lastIndexOf("Score:") + 6));
                    return score2 - score1;
                }
            });

            // 遍历排序后的List，为每一行记录添加“第x名”前缀
            for (int i = 0; i < recordList.size(); i++) {
                String record = "第" + (i + 1) + "名," + recordList.get(i);
                recordList.set(i, record);
            }

            // 将排序后的记录写入到文件中
            FileWriter fileWriter = new FileWriter(outputFileName);
            for (String record : recordList) {
                fileWriter.write(record + "\n");
            }
            fileWriter.close();

            //System.out.println("排序并写入成功！");
        } catch (IOException e) {
            System.out.println("读取或写入文件时出现错误：" + e.getMessage());
        }
    }




    //***********************
    //      Action 各部分
    //***********************


    private boolean timeCountAndNewCycleJudge() {
        cycleTime += timeInterval;
        if (cycleTime >= cycleDuration && cycleTime - timeInterval < cycleTime) {
            // 跨越到新的周期
            cycleTime %= cycleDuration;
            return true;
        } else {
            return false;
        }
    }

    private void shootAction() {
        // TODO 敌机射击 √
        for (AbstractAircraft aircraft : enemyAircrafts) {
            enemyBullets.addAll(aircraft.shoot());
        }
        // 英雄射击
        heroBullets.addAll(heroAircraft.shoot());
    }

    private void bulletsMoveAction() {
        for (BaseBullet bullet : heroBullets) {
            bullet.forward();
        }
        for (BaseBullet bullet : enemyBullets) {
            bullet.forward();
        }
    }

    private void aircraftsMoveAction() {
        for (AbstractAircraft enemyAircraft : enemyAircrafts) {
            enemyAircraft.forward();
        }
    }

    private void supplyMoveAction() {
        for (AbstractSupply supply : supplys) {
            supply.forward();
        }
    }


    /**
     * 碰撞检测：
     * 1. 敌机攻击英雄
     * 2. 英雄攻击/撞击敌机
     * 3. 英雄获得补给
     */
    private void crashCheckAction() {
        // TODO 敌机子弹攻击英雄
        for (BaseBullet bullet : enemyBullets) {
            if (bullet.notValid()) {
                continue;
            }
            if (heroAircraft.crash(bullet)) {
                heroAircraft.decreaseHp(bullet.getPower());
                bullet.vanish();
            }
        }


        // 英雄子弹攻击敌机
        for (BaseBullet bullet : heroBullets) {
            if (bullet.notValid()) {
                continue;
            }
            for (AbstractAircraft enemyAircraft : enemyAircrafts) {
                if (enemyAircraft.notValid()) {
                    // 已被其他子弹击毁的敌机，不再检测
                    // 避免多个子弹重复击毁同一敌机的判定
                    continue;
                }
                if (enemyAircraft.crash(bullet)) {
                    // 敌机撞击到英雄机子弹
                    // 敌机损失一定生命值
                    enemyAircraft.decreaseHp(bullet.getPower());
                    bullet.vanish();
                    if (enemyAircraft.notValid()) {
                        // TODO 获得分数，产生道具补给
                        //如果击毁的是elite敌机，才产生道具补给, 否则不产生道具
                        // 产生道具补给, 道具的方向和速度与敌机相同
                        if (enemyAircraft instanceof EliteEnemy) {
                            score += ((EliteEnemy) enemyAircraft).getScoreAward();
                            bossGetScore += ((EliteEnemy) enemyAircraft).getScoreAward();
                            ((EliteEnemy) enemyAircraft).generateSupply(supplys);
                        }
                        if (enemyAircraft instanceof BossEnemy) {
                            isBossAlive = false;
                            score += ((BossEnemy) enemyAircraft).getScoreAward();
                            bossGetScore = 0;
                            //产生3个道具
                            //todo  道具也要扇形散射? √
                            ((BossEnemy) enemyAircraft).generateSupply(supplys);
                        }
                        if (enemyAircraft instanceof MobEnemy) {
                            score += ((MobEnemy) enemyAircraft).getScoreAward();
                            bossGetScore += ((MobEnemy) enemyAircraft).getScoreAward();
                        }
                    }
                }
                // 英雄机 与 敌机 相撞，均损毁
                if (enemyAircraft.crash(heroAircraft) || heroAircraft.crash(enemyAircraft)) {
                    enemyAircraft.vanish();
                    heroAircraft.decreaseHp(Integer.MAX_VALUE);
                }
            }
        }


    }


    // Todo: 我方碰撞道具，道具生效

    private void supplyGotoWork() {


        for (AbstractSupply supply : supplys) {
            if (supply.notValid()) {
                continue;
            }
            if (heroAircraft.crash(supply)) {
                if (supply instanceof HealingSupply) {
                    supply.activate(heroAircraft, enemyBullets, enemyAircrafts);
                    supply.vanish();
                } else if (supply instanceof FireSupply) {

                    supply.activate(heroAircraft, enemyBullets, enemyAircrafts);
                    supply.vanish();
                } else if (supply instanceof BombSupply) {

                    supply.activate(heroAircraft, enemyBullets, enemyAircrafts);
                    supply.vanish();
                }
                supply.vanish();
            }
        }

    }


    /**
     * 后处理：
     * 1. 删除无效的子弹
     * 2. 删除无效的敌机
     * <p>
     * 无效的原因可能是撞击或者飞出边界
     */
    private void postProcessAction() {
        enemyBullets.removeIf(AbstractFlyingObject::notValid);
        heroBullets.removeIf(AbstractFlyingObject::notValid);
        enemyAircrafts.removeIf(AbstractFlyingObject::notValid);
        supplys.removeIf(AbstractFlyingObject::notValid);

    }
    //todo

    //***********************
    //      Paint 各部分
    //***********************

    /**
     * 重写paint方法
     * 通过重复调用paint方法，实现游戏动画
     *
     * @param g
     */
    @Override
    public void paint(Graphics g) {
        super.paint(g);

        // 绘制背景,图片滚动
        g.drawImage(ImageManager.BACKGROUND_IMAGE, 0, this.backGroundTop - Main.WINDOW_HEIGHT, null);
        g.drawImage(ImageManager.BACKGROUND_IMAGE, 0, this.backGroundTop, null);
        this.backGroundTop += 1;
        if (this.backGroundTop == Main.WINDOW_HEIGHT) {
            this.backGroundTop = 0;
        }

        // 先绘制子弹，后绘制飞机
        // 这样子弹显示在飞机的下层
        try {
            paintImageWithPositionRevised(g, enemyBullets);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            paintImageWithPositionRevised(g, heroBullets);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        try {
            paintImageWithPositionRevised(g, enemyAircrafts);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            paintImageWithPositionRevised(g, supplys);//TODO paint supply
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        g.drawImage(ImageManager.HERO_IMAGE, heroAircraft.getLocationX() - ImageManager.HERO_IMAGE.getWidth() / 2,
                heroAircraft.getLocationY() - ImageManager.HERO_IMAGE.getHeight() / 2, null);

        //绘制得分和生命值
        paintScoreAndLife(g);

    }

    private void paintImageWithPositionRevised(Graphics g, List<? extends AbstractFlyingObject> objects) throws IOException {
        if (objects.size() == 0) {
            return;
        }

        for (AbstractFlyingObject object : objects) {
            BufferedImage image = object.getImage();


            assert image != null : objects.getClass().getName() + " has no image! ";
            g.drawImage(image, object.getLocationX() - image.getWidth() / 2,
                    object.getLocationY() - image.getHeight() / 2, null);
        }
    }

    private void paintScoreAndLife(Graphics g) {
        int x = 10;
        int y = 25;
        g.setColor(new Color(16711680));
        g.setFont(new Font("SansSerif", Font.BOLD, 22));
        g.drawString("SCORE:" + this.score, x, y);
        y = y + 20;
        g.drawString("LIFE:" + this.heroAircraft.getHp(), x, y);
    }


}
