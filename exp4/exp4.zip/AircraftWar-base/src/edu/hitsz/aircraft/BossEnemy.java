package edu.hitsz.aircraft;

import edu.hitsz.factory.BombSupplyFactory;
import edu.hitsz.factory.FireSupplyFactory;
import edu.hitsz.factory.HealingSupplyFactory;
import edu.hitsz.factory.SupplyFactory;
import edu.hitsz.strategy.ScatterShootStrategy;
import edu.hitsz.supply.AbstractSupply;

import java.util.List;

/**
 * @author wlx04
 */
public class BossEnemy extends AbstractEnemyAircraft {



    private final int supply_amount = 3;



    public BossEnemy(int locationX, int locationY, int speedX, int speedY, int hp, int shootNum, int power, int direction, boolean isHero) {
        super(locationX, locationY, speedX, speedY, hp, shootNum, power, 1, false);
        this.setShootStrategy(new ScatterShootStrategy());

    }

    public int getScoreAward() {
        return 100;
    }



    @Override
    public void generateSupply(List<AbstractSupply> supplys) {
        //todo BOSS机的道具 √
        for (int i = 0; i < supply_amount; i++) {
            SupplyFactory supplyfactory;
            double rate = Math.random();
            if (rate > 0.9) {
                // 不产生随机道具
                return;
            } else if (rate > 0.6) {
                supplyfactory = new BombSupplyFactory();

            } else if (rate > 0.3) {
                supplyfactory = new HealingSupplyFactory();

            } else {
                supplyfactory = new FireSupplyFactory();

            }
            supplys.add(supplyfactory.createSupply(locationX + (i * 2 - supply_amount + 1) * 10, locationY, (i * 2 - supply_amount + 1), 5));
        }

    }
}
