package edu.hitsz.record;

public class record {
    private String userName;
    private String time;
    private int score;
    private int recordId;

    public record(String userName, String time, int score, int recordId) {
        this.userName = userName;
        this.time = time;
        this.score = score;
        this.recordId = recordId;
    }

    public String getUserName() {
        return this.userName;
    }

    public String getTime() {
        return this.time;
    }
    public int getRecordId() {
        return this.recordId;
    }
    public int  getScore(){
        return this.score;
    }

    public void setRecordId(int recordId) {
        this.recordId = recordId;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public void setScore(int score) {
        this.score = score;
    }
}
