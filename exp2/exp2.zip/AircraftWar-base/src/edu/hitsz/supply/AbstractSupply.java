package edu.hitsz.supply;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.basic.AbstractFlyingObject;
import edu.hitsz.bullet.BaseBullet;

import java.util.List;

import static edu.hitsz.aircraft.HeroAircraft.getHeroAircraftInstance;


/**
 * 抽象道具类
 * 子类有bomb, fire, healing
 */

public abstract class AbstractSupply extends AbstractFlyingObject {

    public AbstractSupply(int locationX, int locationY, int speedX, int speedY) {
        super(locationX, locationY, speedX, speedY);
    }


    /**
     * @param heroAircraft   英雄机
     * @param enemyBullets   敌人的子弹
     * @param enemyAircrafts 敌人
     */
    abstract public void activate(HeroAircraft heroAircraft, List<BaseBullet> enemyBullets, List<AbstractAircraft> enemyAircrafts);


    HeroAircraft heroAircraft = getHeroAircraftInstance();


}
