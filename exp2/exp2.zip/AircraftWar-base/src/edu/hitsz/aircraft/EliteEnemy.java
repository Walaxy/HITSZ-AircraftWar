package edu.hitsz.aircraft;

import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.HeroBullet;

import java.util.LinkedList;
import java.util.List;

/**
 * 精英敌机
 * 按设定周期射击
 * 坠毁后会随机产生某种道具(向下飞行)/or不产生
 *
 * @author caphhh
 */


public class EliteEnemy extends AbstractEnemyAircraft {
    private int shootNum = 1;//子弹一次的发射数量
    private int power = 30;//子弹伤害
    /**
     * 子弹射击方向 (向上发射：1，向下发射：-1)
     */
    private int direction = 1;//精英机和英雄机方向相反

    /**
     * @param locationX 精英机位置x坐标
     * @param locationY 精英机位置y坐标
     * @param speedX    精英机射出的子弹的基准速度（精英机无特定速度）
     * @param speedY    精英机射出的子弹的基准速度（精英机无特定速度）
     * @param hp        初始生命值
     */
    public EliteEnemy(int locationX, int locationY, int speedX, int speedY, int hp) {
        super(locationX, locationY, speedX, speedY, hp);
    }

    @Override
    public List<BaseBullet> shoot() {
        List<BaseBullet> res = new LinkedList<>();
        int x = this.getLocationX();
        int y = this.getLocationY() + direction * 2;
        int speedX = 0;
        int speedY = this.getSpeedY() + direction * 5;
        BaseBullet bullet;
        for (int i = 0; i < shootNum; i++) {
            // 子弹发射位置相对飞机位置向前偏移
            // 多个子弹横向分散
            bullet = new HeroBullet(x + (i * 2 - shootNum + 1) * 10, y, speedX, speedY, power);
            res.add(bullet);
        }
        return res;
    }


}
