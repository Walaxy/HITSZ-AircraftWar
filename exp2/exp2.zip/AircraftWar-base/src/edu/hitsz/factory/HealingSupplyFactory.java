package edu.hitsz.factory;

import edu.hitsz.supply.HealingSupply;

public class HealingSupplyFactory implements SupplyFactory {

    @Override
    public HealingSupply createSupply(int locationX, int locationY, int speedX, int speedY) {
        return new HealingSupply(locationX, locationY, speedX, 5);
    }

}