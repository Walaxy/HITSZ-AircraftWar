package edu.hitsz.factory;

import edu.hitsz.supply.BombSupply;

public class BombSupplyFactory implements SupplyFactory {

    @Override
    public BombSupply createSupply(int locationX, int locationY, int speedX, int speedY) {
        return new BombSupply(locationX, locationY, speedX, 5);
    }
}
